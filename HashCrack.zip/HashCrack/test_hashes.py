import hashlib

def show_hashes(pwd: str):
    print(f"\nPassword: {repr(pwd)}")
    print("  MD5   :", hashlib.md5(pwd.encode()).hexdigest())
    print("  SHA1  :", hashlib.sha1(pwd.encode()).hexdigest())
    print("  SHA256:", hashlib.sha256(pwd.encode()).hexdigest())
    print("  SHA512:", hashlib.sha512(pwd.encode()).hexdigest())

if __name__ == "__main__":
    for p in [
        "shadow123",
        "root007",
        "hello123",
        "a1b",
    ]:
        show_hashes(p)
