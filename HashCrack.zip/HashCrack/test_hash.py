import hashlib

plain = "p@ssword"
h = hashlib.md5(plain.encode()).hexdigest()
print(h)

for pwd in ["shadow123", "root007"]:
    h = hashlib.md5(pwd.encode()).hexdigest()
    print(pwd, "->", h)
